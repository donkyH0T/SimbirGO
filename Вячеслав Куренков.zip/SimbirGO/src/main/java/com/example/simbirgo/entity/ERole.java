package com.example.simbirgo.entity;

public enum ERole {
	ROLE_USER,
    ROLE_ADMIN
}
